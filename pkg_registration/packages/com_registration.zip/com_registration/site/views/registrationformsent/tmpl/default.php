<?php echo $this->presenter->body(); ?>
