DROP TABLE IF EXISTS `#__registration_events`;
DROP TABLE IF EXISTS `#__registration_participants`;